<?php
/* Smarty version 3.1.39, created on 2021-12-14 02:59:19
  from 'C:\xampp\htdocs\example\cismart.3.1.11\application\views\base\operator\sidebar.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b7fa773e1766_45588790',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ef5d9cffa443aa8f2746ca8992503081860d4c04' => 
    array (
      0 => 'C:\\xampp\\htdocs\\example\\cismart.3.1.11\\application\\views\\base\\operator\\sidebar.html',
      1 => 1639445266,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b7fa773e1766_45588790 (Smarty_Internal_Template $_smarty_tpl) {
?><ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
    <?php echo (($tmp = @$_smarty_tpl->tpl_vars['list_sidebar_nav']->value)===null||$tmp==='' ? '' : $tmp);?>

</ul>
<?php }
}
