<?php
/* Smarty version 3.1.39, created on 2021-12-14 02:59:43
  from 'C:\xampp\htdocs\example\cismart.3.1.11\application\views\home\admin\welcome.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b7fa8fb63be2_64490833',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '465fa4521a29da37dad2da6db4e5e6db5ad57e6d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\example\\cismart.3.1.11\\application\\views\\home\\admin\\welcome.html',
      1 => 1639445266,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b7fa8fb63be2_64490833 (Smarty_Internal_Template $_smarty_tpl) {
}
}
