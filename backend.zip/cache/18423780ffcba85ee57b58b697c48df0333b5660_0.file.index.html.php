<?php
/* Smarty version 3.1.39, created on 2021-12-15 09:54:25
  from 'C:\xampp\htdocs\example\cismart.3.1.11\application\views\operator\welcome\index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b958e179b094_07682181',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '18423780ffcba85ee57b58b697c48df0333b5660' => 
    array (
      0 => 'C:\\xampp\\htdocs\\example\\cismart.3.1.11\\application\\views\\operator\\welcome\\index.html',
      1 => 1639536862,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b958e179b094_07682181 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <?php echo '<script'; ?>
 type="text/javascript" src="https://app.midtrans.com/snap/snap.js" data-client-key=<?php echo '<?php ';?>
echo getClientKey()
            <?php echo '?>';?>

    <?php echo '</script'; ?>
>
</head>
<body>
    <span>Daftar karyawan</span>
    <a onclick="printData()" class="btn btn-info ">Cetak</a>
    <button class="btnpay btn-info btn-xl" id="pay-button" data-harga="<?php echo '<?=';?>
 $totalharga <?php echo '?>';?>
" value="<?php echo '<?=';?>
 $dt->id_transaksi <?php echo '?>';?>
"><i
        class="fas fa-credit-card"></i>&nbsp; Test API</button>

    <table border="1"  id="printTable" class="table table-striped table-bordered" width="100%"> 
        <thead>
            <td>name</td>
            <td>action</td>
        </thead>
        <tbody>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['datas']->value, 'foo');
$_smarty_tpl->tpl_vars['foo']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->do_else = false;
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['foo']->value->name;?>
</td>
                <td> <form action="<?php echo $_smarty_tpl->tpl_vars['config']->value->site_url('operator/welcome/delete');?>
"  method="post">
                       
                    <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['hash'];?>
"> 
                   
                        <input type="hidden" name="nama_delete" value="<?php echo $_smarty_tpl->tpl_vars['foo']->value->name;?>
"> 
                         
                        <input type="submit" value="Hapus" class="btn btn-info "></td>
                    </form>	
                </td>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                
            </tr>
        </tbody>
    </table>

    <div class="box box-solid box-info">
        <form action="<?php echo $_smarty_tpl->tpl_vars['config']->value->site_url('operator/welcome/add');?>
" method="post">
		<table style="margin:20px auto;">
        <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['hash'];?>
">  
			<tr>
				<td>
                    Nama</td>
				<td><input type="text" name="inp_nama" id="inp_nama"></td>
			</tr>
            <tr>
				<td></td>
				<td>
                    
                    <input type="submit" value="Tambah" class="btn btn-info "></td>
			</tr>
			
		</table>
	</form>	
    </div>
    <div class="box box-solid box-info">
        <form action="<?php echo $_smarty_tpl->tpl_vars['config']->value->site_url('operator/welcome/update');?>
" method="post">
		<table style="margin:20px auto;">
        <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['hash'];?>
">  
			<tr>
			</tr>
            <tr>
				<td>
                    <span>Update data</span>
                    
                    <select name="update_from">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['datas']->value, 'foo');
$_smarty_tpl->tpl_vars['foo']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->do_else = false;
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['foo']->value->name;?>
"><?php echo $_smarty_tpl->tpl_vars['foo']->value->name;?>
</option>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </select>
                    <td> to <input type="text" name="upd_nama" id="upd_nama"></td></td>
				<td><input type="submit" value="Update"  class="btn btn-info "></td>
			</tr>
			
		</table>
	</form>	
    </div>

    
    <div>

        <form action="<?php echo $_smarty_tpl->tpl_vars['config']->value->site_url('operator/welcome/delete');?>
" method="post">
		<table style="margin:20px auto;">
        <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['hash'];?>
">  
			<tr>
				<td>Nama</td>
			</tr>
            <tr>
				<td>
                    <span>Delete data</span>
                    
                    <select name="nama_delete">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['datas']->value, 'foo');
$_smarty_tpl->tpl_vars['foo']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->do_else = false;
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['foo']->value->name;?>
"><?php echo $_smarty_tpl->tpl_vars['foo']->value->name;?>
</option>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </select>
                   
				<td><input type="submit" value="Delete" class="btn btn-info"></td>
			</tr>
			
		</table>
	</form>	
    </div>
 
  <form action="<?php echo $_smarty_tpl->tpl_vars['config']->value->site_url('operator/welcome/process_upload');?>
" method="post" enctype="multipart/form-data">
  <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['hash'];?>
">   
  <table class="table-input" width="100%">
          <tr>
              <th>Upload File</th>
          </tr>
          <tr>
              <td>Browse File</td>
              <td><input type="file" name="upload_file"></td>
          </tr>
          <tr>
              <td></td>
              <td>
                  <input type="submit" name="simpan" value="upload" class="edit-button">
              </td>
          </tr>
      </table>
  </form>
</body>
<?php echo '<script'; ?>
>
    function printData()
{
   var divToPrint=document.getElementById("printTable");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}
$(document).ready(function() {
$('.btnpay').click(function(event) {

event.preventDefault();
var order_id = $(this).attr('value');
var harga = $(this).attr('data-harga');
$.ajax({
    url: 'welcome/token',
    data: {
        order_id: order_id,
        harga: harga
    },
    method: "POST",
    cache: false,

    success: function(data) {
        snap.pay(data, {

            onSuccess: function(result) {
                // alert("transaksi sukses");
                location.reload();
            },
            onPending: function(result) {
                // alert("pending");
                location.reload();
            },
            onError: function(result) {
                // alert("error");
                location.reload();
            },
            onClose: function(result) {
                alert("Anda Menutup Pembayaran");
                location.reload();
            }
        });
    }
});
});

});
<?php echo '</script'; ?>
>
</html><?php }
}
