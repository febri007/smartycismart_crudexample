<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
// load base class if needed
require_once APPPATH . 'controllers/base/OperatorBase.php';

class Kampung extends ApplicationBase
{
    // constructor
    public function __construct()
    {
        parent::__construct();
        // load model
        // load library
        $this->load->library('tnotification');
        $this->load->library('datetimemanipulation');
        
        // set page header
        $this->smarty->assign('page_header', 'Dashboard');
    }

    // welcome operator
    public function index()
    {

        $this->tnotification->display_notification();
        $this->tnotification->display_last_field();
        $this->load->model('m_kampung');


        //send data from db to parameters
        $send = $this->m_kampung->getdata()->result();
        // print_r($send);
        $this->smarty->assign('datas', $send);
        $nd = $this->m_kampung->getdata()->result_array();
        // print_r($nd);
        //send data to option value
        $this->smarty->assign('cust_ids', $nd
            );
        $this->smarty->assign('cust_names', $nd);
        $this->smarty->assign('customer_id', 92);
        // set page rules
        $this->_set_page_rule("R");
        // set template content
        
        $this->smarty->assign("template_content", "operator/datakampung/v_dtkampung.html");
        $this->smarty->assign('user', $this->com_user['user_id']);
        $this->smarty->assign('data',$this->m_kampung->getdata());
        // $this->smarty->display('text.tpl'); 

        // output
        parent::display();
    }
     // add
     public function process_add(){
        $this->load->model('m_kampung');
		$nama = $this->input->post('txt_nama');
        $jk  = $this->input->post('txt_jk');
        $ket  = $this->input->post('txt_keterangan');
		$data = array(
			'nama' => $nama,
            'jk' => $jk,
            'keterangan' => $ket
    );

        if($this->m_kampung->insert_kampung($data)){
            echo "data inserted";
        }else{
            echo "data fails";
        }
	}
    public function process_update(){
        $this->load->model('m_kampung');
        $id = $this->input->post('id1');
		$nama = $this->input->post('nama1');
        $jk  = $this->input->post('jk1');
        $ket  = $this->input->post('ket1');
		$data = array(
			'nama' => $nama,
            'jk' => $jk,
            'keterangan' => $ket
    );

        if($this->m_kampung->update_kampung($id,$data)){
            echo "data Updated";
        }else{
            echo "data fails";
        }
	}

    public function process_hapus(){
        $this->load->model('m_kampung');
        $id1 = $this->input->post('id1');
        if($this->m_kampung->delete($id1)){
            echo "data deleted";
            ?><script>
                alert("Sukses Menghapus");
            </script><?php
        }else{
            echo "data fails";
        }
    }

    public function upload(){
        $this->smarty->assign("template_content", "operator/welcome/index.php");

        $this->tnotification->display_notification();
        $this ->tnotification->display_last_field();
        parent::display();
    }

    public function process_upload(){
        $this->load->library('tupload');

        if(empty($_FILES['upload_file']['tmp_name'])) {
            $this->tnotification->set_error_message('file not found');
            $this->tnotification->sent_notification("error","process fails");
        }
        if(!empty($_FILES['upload_file']['tmp_name'])){
            echo $_FILES['upload_file']['tmp_name'];
        $config['upload_path'] = 'resource/doc/';
        $config['allowed_types'] = '*';
            if($this->tupload->do_upload('upload_file')){
                $this->tnotification->sent_notification("sucess","data diupload");
            }else{
                $this->tnotification->set_error_message($this->tupload->display_errors());
                $this->tnotification->sent_notification("error","process fails");
            }
         }

         
        //  redirect("operator/welcome/");
    }
         
    public function jqueryui(){
        $this->smarty->assign("template_content", "operator/welcome/index.html");
        //load javascript
        // $this->smarty->load_javascript("resource/js/jquery/jquery-3.5.1.min.js");
        // $this->smarty->load_javascript("resource/js/jquery/jquery.min.js");
        $this->smarty->load_javascript("resource/js/jquery/jquery.min.js");
        parent::display();
    }
}
