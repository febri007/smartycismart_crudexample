<?php

// class for core system
class M_kampung extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    // get site data
	function getdata(){
		return $this->db->get("kampung");
	}
    function insert_kampung($data){
        return $this->db->insert('kampung', $data);
    }
    function update_kampung($id,$data){
        $this->db->where('id', $id);
        return $this->db->update('kampung', $data);
    }
    function delete($id){
        return $this->db->delete('kampung', array('id' => $id)); 
    }
    function get_rows(){
        return $this->db->query("SELECT COUNT(name) FROM kampung");
    }
}
