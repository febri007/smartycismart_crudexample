<?php
header('Location: ../index.php/login/adminlogin');
?>